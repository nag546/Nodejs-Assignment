const express = require('express');
const app = express();
const apiRequest = require('request');
const bodyPaser = require('body-parser');
const session = require('express-session');

const eventsServiceUrl = 'http://localhost:9090/api/events';
const employeesServiceUrl = 'http://localhost:9090/api/employees';

const employeeObj = require('./dal/employee-dal');
const eventsObj = require('./dal/events-dal');

app.use(express.static(`${__dirname}/public/`));
app.use(bodyPaser.urlencoded({extended: false}));
app.use(session({
    secret: 'syne-secret',
    resave: false,
    saveUninitialized: true
}));

let appSession ={
    token: null

}

app.set('views', './views');
app.set('view engine', 'pug');

app.get('/', (request, response) => {
    //response.send('<h1>Welcome to Synechron Events Poral.!</h1>')
    //response.sendFile(`${__dirname}/views/home.html`);    // sendFile is only for html, css files
    response.render("home", {
        title: 'Welcome to synechron portal.!',
        subTitle: 'Published by synechron hyd HR'
    });
});

app.get('/home', (request, response) => {
    response.render("home", {
        title: 'Welcome to synechron portal.!',
        subTitle: 'Published by synechron hyd HR'
    });
});

/**
 * Star of Employees and Employee detail route
 */
/** app.get('/employees', (request, response) => {
    response.render("employees-list", {
        title: 'Synechron employees list',
        subTitle: 'core development team members',
        employees: employeeObj.getAllEmployees()
    });
});

app.get('/employees/:id', (request, response) => {
    let employeeId = request.params.id;
    response.render("employee-details", {
        title: 'Details of - ',
        employee: employeeObj.getEmployeeDetails(employeeId)
    });
}); */

app.get('/employees', (request, response) => {
    let options = {
        url: employeesServiceUrl,
        headers: {
            "x-access-token": appSession.token
        }
    }
    if(appSession.token) {
        apiRequest(options, (err, res, body) => {
            if(err) {
                response.send('<h1>Somehing went wrong</h1>');
            }
            response.render("employees-list", {
                title: 'Synechron Employees list',
                subTitle: 'Employees team members',
                employees: JSON.parse(body)    //eventsObj.getAllEvents()
            });
        })
    } else {
        response.redirect('/login');
    }
    
});

app.get('/employees/new', (request, response) => {
    response.render("register-employee", {
        title: 'New Employee Registration form!'
    });
});

app.post('/employees/new', (request, response) => {
    let options = {
        url: employeesServiceUrl,
        method: "POST",
        json: true,
        body: request.body,
        headers: {
            "x-access-token": appSession.token
        }
    }
    if(appSession.token) {
        apiRequest(options, (err, res, body) => {
            if(err) {
                response.send('<h1>Something went wrong</h1>');
            }
            response.redirect('/employees');
        })
    } else {
        response.redirect('/login');
    }
});

app.get('/employees/:id', (request, response) => {
    let employeeId = request.params.id;
    let options = {
        url: `${employeesServiceUrl}/${employeeId}`,
        headers: {
            "x-access-token": appSession.token
        }
    }
    if(appSession.token) {
        apiRequest(options, (err, res, body) => {
            if(err) {
                response.send('<h1>Something went wrong</h1>');
            }
            response.render("employee-details", {
                title: 'Details of - ',
                employee: JSON.parse(body) //eventsObj.getEventDetails(eventId)
            });
        });
    } else {
        response.redirect('/login');
    }
});

/**
 * End of Employees and Employee detail route
 */


/**
 * Star of Events and Event detail route
 */
app.get('/events', (request, response) => {
    let options = {
        url: eventsServiceUrl,
        headers: {
            "x-access-token": appSession.token
        }
    }
    if(appSession.token) {
        apiRequest(options, (err, res, body) => {
            if(err) {
                response.send('<h1>Somehing went wrong</h1>');
            }
            response.render("events-list", {
                title: 'Synechron events list',
                subTitle: 'Events team members',
                events: JSON.parse(body)    //eventsObj.getAllEvents()
            });
        })
    } else {
        response.redirect('/login');
    }
    
});

app.get('/events/new', (request, response) => {
    response.render("register-event", {
        title: 'New Event Registration form!'
    });
});

app.post('/events/new', (request, response) => {
    let options = {
        url: eventsServiceUrl,
        method: "POST",
        json: true,
        body: request.body,
        headers: {
            "x-access-token": appSession.token
        }
    }
    if(appSession.token) {
        apiRequest(options, (err, res, body) => {
            if(err) {
                response.send('<h1>Something went wrong</h1>');
            }
            response.redirect('/events');
        })
    } else {
        response.redirect('/login');
    }
});

app.get('/events/:id', (request, response) => {
    let eventId = request.params.id;
    let options = {
        url: `${eventsServiceUrl}/${eventId}`,
        headers: {
            "x-access-token": appSession.token
        }
    }
    if(appSession.token) {
        apiRequest(options, (err, res, body) => {
            if(err) {
                response.send('<h1>Something went wrong</h1>');
            }
            response.render("event-details", {
                title: 'Details of - ',
                event: JSON.parse(body) //eventsObj.getEventDetails(eventId)
            });
        });
    } else {
        response.redirect('/login');
    }
});
/**
 * End of Events and Event detail route
 */

app.get('/login', (request, response) => {
    response.render("login", {
        title: 'Synechron Authentication '
    });
});

app.post('/login', (request, response) => {
    let body = {
        name: request.body.name,
        password: request.body.password
    }
    const options = {
        url: 'http://localhost:9090/api/auth',
        //method:"POST",
        form: body,
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    };
    apiRequest.post(options, (req, res, body) => {
        //console.log(body);
        //response.send(body);
        appSession = request.session;
        appSession.token = JSON.parse(body).token;
        response.redirect('/home');
    });

});

app.listen(3000, () => console.log('synechron event portal is listenin on port : 3000'));
