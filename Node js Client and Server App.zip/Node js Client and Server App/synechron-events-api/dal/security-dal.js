const mongojs = require('mongojs');
const jwt = require('jsonwebtoken');
const db = mongojs('synechron-events-db', ['users']);

const config = require('../config');

let tokenResponse={
    success:false,
    role: '',
    token: null,
    message: ''
}

class SecuriyDal {
    constructor() {

    }
   checkCredentials(userName, password) {
        return new Promise((resolve, reject) => {
            db.users.findOne({
                name:userName
            }, (err, user) => {
                if(err) {
                    reject(err);
                }
                if(!user){
                    resolve({
                        ...tokenResponse,
                        message:"Access Denied please check ur User Name.!"
                    })
                } else if(user) {
                    if(user.password != password) {
                        resolve({
                            ...tokenResponse,
                            message:"Access Denied please check ur password.!"
                        })
                    } else {
                        let authToken = jwt.sign(user, config.secet, {expiresIn:3000})
                        resolve({
                            ...tokenResponse,
                            success:true,
                            role:user.role,
                            token: authToken
                        })
                    }
                }
            })
        })
    }
}

module.exports = new SecuriyDal();
