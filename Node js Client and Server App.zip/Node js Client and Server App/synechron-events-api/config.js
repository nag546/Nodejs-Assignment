module.exports = {
    "secet":"synenodejstrnju12019hyd"
}