const express = require('express');
const jwt = require('jsonwebtoken');
const config = require('../config');

const eventDal = require('../dal/event-dal');

const eventRoutes = express.Router();
eventRoutes.use((request, response, next) => {
    let authToken = {
        token: request.body.token || request.query.token || request.headers["x-access-token"]
    };
    console.log(authToken.token)
    if(authToken.token) {
        jwt.verify(authToken.token, config.secet, (err, decoded) => {
            if(err) {
                response.json({
                    success: false,
                    message: 'we are unable to verify the token'
                });
            }
            next();
        })
    } else {
        response.json({
            success: false,
            message: "please send the token for authentication"
        })
    }
})

eventRoutes.get('/', (request, response) => {
    eventDal.getAllEvents().then(
        events => response.json(events),
        reason => response.json(reason)
    )
});

eventRoutes.post('/', (request, response) => {
    eventDal.registerNewEvent(request.body).then(
        event => response.json(event),
        reason => response.json(reason)
    )
});

eventRoutes.get('/:id', (request, response) => {
    eventDal.getEventDetails(request.params.id).then(
        event => response.json(event),
        reason => response.json(reason)
    )
});


module.exports = eventRoutes;